#include "LCD.h"

void putc(unsigned char ch){

	writeLCD(ch);
}
