#include "LCD.h"

void putch(unsigned char ch){

	writeLCD(ch);
}
