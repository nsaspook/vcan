//////////////////////////////////////////////
// Novo RTOS configuration file
//
// Copyright(C) 2006-2009 Pavel Baranov
// Copyright(C) 2006-2009 David Hobday                   
// All Rights Reserved                                    
//
// Author(s): David Hobday
// Date 28-June 2006
//
//////////////////////////////////////////////
//
//
//

#define _NOVOCFG_H_

// Maximum number of tasks and events
#define MAX_TASKS 3
#define MAX_EVENTS 1

// Tick count data size
typedef unsigned int TICK_COUNT;

// future - the ability to disable features to save RAM and ROM
// #define _NOVO_EVENTS
// #define _NOVO_TIMERS
// #define _NOVO_PRIORITIES
