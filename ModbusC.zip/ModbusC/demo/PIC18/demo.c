/*
 * FreeModbus Libary: BARE Demo Application
 * Copyright (C) 2006 Christian Walter <wolti@sil.at>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * File: $Id: demo.c,v 1.1 2006/08/22 21:35:13 wolti Exp $
 */

/* ----------------------- Modbus includes ----------------------------------*/
#include "mb.h"
#include "mbport.h"
#include "icd2.h"

#ifdef USING_NOVO
#include "novocfg_pic18t3e1ts2.h"
#include "novo.h"
#endif


/* ----------------------- Defines ------------------------------------------*/
#define REG_INPUT_START 1000
#define REG_INPUT_NREGS 4

#define REG_HOLDING_START 1
#define REG_HOLDING_NREGS 2

#define TIMER1_CLOCKS_PER_US   ((FOSC/4)/1000000)
#define TIMER1_PRESCALER_VALUE  1
#define TIMER1_1MS_LOAD (0x10000 - ((TIMER1_CLOCKS_PER_US * 1000 )/TIMER1_PRESCALER_VALUE))

#define MSB(x) (((x)>>8)&0xFF)
#define LSB(x) ((x)&0xFF)

extern BOOL xMBRTUReceiveFSM( void );
extern BOOL xMBRTUTimerT35Expired( void );
extern BOOL xMBRTUTransmitFSM( void );

extern void TaskMBPoll();

/* ----------------------- Static variables ---------------------------------*/

//These are all for testing
static USHORT   usRegInputStart = REG_INPUT_START;
static USHORT   usRegInputBuf[REG_INPUT_NREGS];
static USHORT   usRegHoldingBuf[REG_HOLDING_NREGS];



/* ----------------------- Start implementation -----------------------------*/

#pragma DATA _CONFIG1H, _OSC_XT_1H
#pragma DATA _CONFIG2L, _BOREN_OFF_2L
#pragma DATA _CONFIG2H, _WDT_OFF_2H
#pragma DATA _CONFIG3H, _MCLRE_ON_3H


void interrupt_low( void )
{
#ifdef USING_NOVO 
	if( pir1.TMR1IF == 1 )
	{
      SysTimerUpdate();
	   clear_bit(pir1, TMR1IF);
	   /* Enable the timer with the timeout passed to xMBPortTimersInit( ) */    
      tmr1h = MSB(TIMER1_1MS_LOAD);
      tmr1l = LSB(TIMER1_1MS_LOAD);
	}
#endif
   if( (pie1.RCIE == 1) && (pir1.RCIF == 1) )
   {
      xMBRTUReceiveFSM();   
   }
   if( (pie1.TXIE == 1) && (pir1.TXIF == 1) )
   {
      xMBRTUTransmitFSM();   
   }
	if( (intcon.TMR0IE == 1) && (intcon.TMR0IF == 1) )
	{
      xMBRTUTimerT35Expired();
	   latb.0 = ~latb.0;
	   clear_bit(intcon, TMR0IF);
	   /* Enable the timer with the timeout passed to xMBPortTimersInit( ) */    
	   HIBYTE(tmr0h, wTimerVal);
	   LOBYTE(tmr0l, wTimerVal);
	}
}

int
main( void )
{
    unsigned char ucStatus;
    eMBErrorCode    eStatus;
    
    //Turn off all A/D channels
    adcon1 = 0x0f;
    //Enable interrupt priority
    set_bit(rcon, IPEN);
    
    //Enable 485 direction output
    clear_bit(DIRECTION_485_TRIS, TRANSMIT_485_BIT);    
    
    //Put some test values in holding reg buffer
    usRegHoldingBuf[0] = 0x1234;
    usRegHoldingBuf[1] = 0x5678;
    
#ifdef USING_NOVO    
    //Init Novo RTOS
    SysInit();
    SysCreateTask(hTaskMB, 0, TaskMBPoll);
//    SysStartTask(hTaskMB);
    
    ucStatus = SysGetTaskStatus(hTaskMB);
    tmr1h = MSB(TIMER1_1MS_LOAD);
    tmr1l = LSB(1);
    clear_bit(pir1, TMR1IF);
    clear_bit(ipr1, TMR1IP);
    set_bit(pie1, TMR1IE);
    t1con = (1<<RD16)|(1<<TMR1ON);
#endif    

    eStatus = eMBInit( 0x0B, 0, 19200, MB_PAR_ODD );

    /* Enable the Modbus Protocol Stack. */
    eStatus = eMBEnable(  );
    set_bit(intcon, GIEH);

    for( ;; )
    {
#ifdef USING_NOVO    
        Sys_Yield();
#else 
        TaskMBPoll();
#endif        
    }
}

eMBErrorCode
eMBRegInputCB( UCHAR * pucRegBuffer, USHORT usAddress, USHORT usNRegs )
{
    eMBErrorCode    eStatus = MB_ENOERR;
    int             iRegIndex;

    if( ( usAddress >= REG_INPUT_START )
        && ( usAddress + usNRegs <= REG_INPUT_START + REG_INPUT_NREGS ) )
    {
        iRegIndex = ( int )( usAddress - usRegInputStart );
        while( usNRegs > 0 )
        {
            *pucRegBuffer++ =
                ( unsigned char )( usRegInputBuf[iRegIndex] >> 8 );
            *pucRegBuffer++ =
                ( unsigned char )( usRegInputBuf[iRegIndex] & 0xFF );
            iRegIndex++;
            usNRegs--;
        }
    }
    else
    {
        eStatus = MB_ENOREG;
    }

    return eStatus;
}

eMBErrorCode
eMBRegHoldingCB( UCHAR * pucRegBuffer, USHORT usAddress, USHORT usNRegs,
                 eMBRegisterMode eMode )
{
    eMBErrorCode    eStatus = MB_ENOERR;
    int             iRegIndex;

    if( (eMode == MB_REG_READ)
        && ( usAddress >= REG_HOLDING_START )
        && ( usAddress + usNRegs <= REG_HOLDING_START + REG_HOLDING_NREGS ) )
    {
        iRegIndex = ( int )( usAddress - REG_HOLDING_START );
        while( usNRegs > 0 )
        {
            *pucRegBuffer++ =
                ( unsigned char )( usRegHoldingBuf[iRegIndex] >> 8 );
            *pucRegBuffer++ =
                ( unsigned char )( usRegHoldingBuf[iRegIndex] & 0xFF );
            iRegIndex++;
            usNRegs--;
        }
    }
    else
    {
        eStatus = MB_ENOREG;
    }

    return eStatus;
}


eMBErrorCode
eMBRegCoilsCB( UCHAR * pucRegBuffer, USHORT usAddress, USHORT usNCoils,
               eMBRegisterMode eMode )
{
    return MB_ENOREG;
}

eMBErrorCode
eMBRegDiscreteCB( UCHAR * pucRegBuffer, USHORT usAddress, USHORT usNDiscrete )
{
    return MB_ENOREG;
}
