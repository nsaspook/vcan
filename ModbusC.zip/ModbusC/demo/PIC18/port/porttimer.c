/*
 * FreeModbus Libary: BARE Port
 * Copyright (C) 2006 Christian Walter <wolti@sil.at>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * File: $Id: porttimer.c,v 1.1 2006/08/22 21:35:13 wolti Exp $
 */

/* ----------------------- Platform includes --------------------------------*/
#include "port.h"

/* ----------------------- Modbus includes ----------------------------------*/
#include "mb.h"
#include "mbport.h"

extern          BOOL( *pxMBPortCBTimerExpired ) ( void );

/* ----------------------- static functions ---------------------------------*/
//void prvvTIMERExpiredISR( void );
SHORT wTimerVal;


#define TIMER_CLOCKS_PER_US   ((FOSC/4)/1000000)

#pragma OPTIMIZE "p"    

/* ----------------------- Start implementation -----------------------------*/
BOOL xMBPortTimersInit( USHORT usTim1Timerout50us )
{
#if MB_TIMER == 0
	#define TIMER_PRESCALER_VALUE  1
        
    t0con = 0x08;	//8 bit timer, no prescaler
//    wTimerVal = 0x10000 - ((TIMER_CLOCKS_PER US * 50 * usTim1Timerout50us)/TIMER_PRESCALER_VALUE);
    wTimerVal = 0x10000 - ((TIMER_CLOCKS_PER_US * 50 * usTim1Timerout50us)/TIMER_PRESCALER_VALUE);
    clear_bit(intcon2, TMR0IP);
    
#endif	
    return TRUE;
}
#pragma OPTIMIZE ""    

/*
inline void
vMBPortTimersEnable( void )
{
    // Enable the timer with the timeout passed to xMBPortTimersInit( )    
	HIBYTE(tmr0h, wTimerVal);
	LOBYTE(tmr0l, wTimerVal);
	clear_bit(intcon, TMR0IF);
	set_bit(intcon, TMR0IE);
	set_bit(t0con, TMR0ON);
	set_bit(intcon, GIEL);
}
*/

void
vMBPortTimersDisable( void )
{
    /* Disable any pending timers. */
    clear_bit(t0con, TMR0ON);
    clear_bit(intcon, TMR0IE);
}

#if 0
/* Create an ISR which is called whenever the timer has expired. This function
 * must then call pxMBPortCBTimerExpired( ) to notify the protocol stack that
 * the timer has expired.
 */
void vMBTIMERExpiredISR( void )
{
    ( void )pxMBPortCBTimerExpired(  );
}
#endif
