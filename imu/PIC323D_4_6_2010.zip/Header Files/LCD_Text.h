void DrawCh(unsigned int x, unsigned int y, unsigned char ch, long fg, long bg);
void DrawStr(unsigned int x, unsigned int y, unsigned char * ch, long fg, long bg);
