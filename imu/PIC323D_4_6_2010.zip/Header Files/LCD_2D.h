void DrawHLine(int s_x, int e_x, int color);
void DrawTriangle(int Tri[3][3], int color);
