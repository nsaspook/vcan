int FrameRow[320];
int FrameRowIndex;

void NewFrame();
void DrawFrameRow();
void FillFrameRow(int color);
