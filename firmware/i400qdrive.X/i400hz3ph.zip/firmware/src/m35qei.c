
#include <proc/p32mk1024mcm100.h>
#include "m35qei.h"
#include <xc.h>
#include <stdio.h>

//struct QEI_DATA m35_1, m35_2, m35_3, m35_4, *m35_ptr;


